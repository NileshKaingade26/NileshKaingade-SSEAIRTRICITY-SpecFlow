# SpecFlow C# Automated Selenium Testing Framework - WebDriver

How to Run

Search solution explorer 
Left click - Clean solution
Then - Build

In Menu
Test --> Windows --> Test explorer

Run all


Troubleshoot tips - Make sure you have all updated packages https://github.com/padmarajnidagundi/SpecflowCSarapPOC/blob/master/specflow/packages.config

Tutorials

For the assertions in the test
http://nunit.org/docs/2.5/assertions.html

For BDD  - SpecFlow - Binding Business Requirements to .NET Code
https://specflow.org/


Keywords : page object model c# selenium specflow
c# page object model example
specflow page object model
pagefactory is obsolete c#
selenium pagefactory c#
selenium pagefactory c# deprecated
page object model with pagefactory in selenium
page object model for selenium scripting

page object model c# selenium specflow
page object model c# tutorial
page object model c# specflow
pagefactory is obsolete c#
pagefactory selenium c#
selenium pagefactory c# deprecated
findsby selenium c#
selenium base page object c sharp


Star this git repo :-) 
